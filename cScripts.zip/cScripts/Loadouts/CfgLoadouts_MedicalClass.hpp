//                M E D I C A L   P L A T O O N

// Medics

class B_medic_F : CAV_Medical_OFFCR {};  // Use for PL/PSG/Bonesaw Team Leader
class rhsusf_navy_marpat_d_medic : CAV_Medical_PLMEDIC {};  // Platoon Medics
class rhsusf_navy_marpat_wd_medic : CAV_Medical_BONESAW {};  // Bonesaw Team Medic
