/* Gear Date 15 NOV 17 */

//                R A N G E R   C O M P A N Y

// Ranger Officer
class rhsusf_socom_marsoc_elementleader : CAV_Ranger_OIC {};

// Ranger Squad Leader
class rhsusf_socom_marsoc_teamchief : CAV_Ranger_2IC {};

// Ranger Team Leader
class rhsusf_socom_marsoc_teamleader : CAV_Ranger_TL {};

// Ranger AR
class rhsusf_socom_marsoc_cso_mechanic : CAV_Ranger_AR {};

// Ranger Grenadier
class rhsusf_socom_marsoc_cso_grenadier : CAV_Ranger_GR {};

// Ranger Rifleman
class rhsusf_socom_marsoc_cso : CAV_Ranger_RM {};

// Ranger Medic
class rhsusf_socom_marsoc_sarc : CAV_Ranger_MEDIC {};

// Sniper
class B_sniper_F : CAV_Sniper {};

// Spotter
class B_spotter_F : CAV_Spotter {};
