//                S 3   T R A I N I N G

// School of Infantry
class B_Rangemaster_F : CAV_SOI_INSTR {};
class B_Soldier_SL_F : CAV_SOI_INSTR_SL {};
class B_Soldier_TL_F : CAV_SOI_STUD_TL {};
class B_soldier_AR_F : CAV_SOI_STUD_AR {};
class B_Soldier_GL_F : CAV_SOI_STUD_GR {};
class B_Soldier_F : CAV_SOI_STUD_RM {};
class B_T_Medic_F : CAV_SOI_STUD_CLS {};
class B_Survivor_F : CAV_BLN_STUD {};

// THE AIRBORNE SCHOOL

class B_officer_F : CAV_JM_INSTR {};
class B_Soldier_PG_F : CAV_JM_STUD {};

// THE ARMOR SCHOOL
class rhsusf_usmc_marpat_wd_crewman : CAV_TCS_INSTR {};
class rhsusf_usmc_marpat_wd_combatcrewman : CAV_TCS_STUD {};

// AVIATION CENTER OF EXCELLENCE
class rhsusf_usmc_marpat_wd_helipilot : CAV_ACE_ROTARY_INSTR {};
class rhsusf_airforce_jetpilot : CAV_ACE_FIXED_INSTR {};
class rhsusf_usmc_marpat_wd_helicrew : CAV_ACE_ROTARY_STUD {};
class rhsusf_airforce_pilot : CAV_ACE_FIXED_STUD {};

